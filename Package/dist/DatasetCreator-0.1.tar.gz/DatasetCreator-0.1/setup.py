from setuptools import setup

setup(name='DatasetCreator',
      version='0.1',
      description='Image Dataset Creator',
      packages=['DatasetCreator'],
      zip_safe=False)
